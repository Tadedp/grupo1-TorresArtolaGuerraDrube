import { Component } from '@angular/core';

@Component({
  selector: 'app-prestamos-usuarios',
  templateUrl: './prestamos-usuarios.component.html',
  styleUrl: './prestamos-usuarios.component.css'
})
export class PrestamosUsuariosComponent {

}
