import { Component } from '@angular/core';

@Component({
  selector: 'app-detalles-perfil',
  templateUrl: './detalles-perfil.component.html',
  styleUrl: './detalles-perfil.component.css'
})
export class DetallesPerfilComponent {

}
