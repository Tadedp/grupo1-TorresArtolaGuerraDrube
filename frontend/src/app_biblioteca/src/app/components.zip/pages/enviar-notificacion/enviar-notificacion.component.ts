import { Component } from '@angular/core';

@Component({
  selector: 'app-enviar-notificacion',
  templateUrl: './enviar-notificacion.component.html',
  styleUrl: './enviar-notificacion.component.css'
})
export class EnviarNotificacionComponent {

}
