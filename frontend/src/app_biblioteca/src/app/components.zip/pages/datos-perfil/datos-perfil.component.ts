import { Component } from '@angular/core';

@Component({
  selector: 'app-datos-perfil',
  templateUrl: './datos-perfil.component.html',
  styleUrl: './datos-perfil.component.css'
})
export class DatosPerfilComponent {

}
