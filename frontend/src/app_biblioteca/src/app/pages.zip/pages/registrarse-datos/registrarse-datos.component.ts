import { Component } from '@angular/core';

@Component({
  selector: 'app-registrarse-datos',
  templateUrl: './registrarse-datos.component.html',
  styleUrl: './registrarse-datos.component.css'
})
export class RegistrarseDatosComponent {

}
